// js/api.js

const URL = 'https://jsonplaceholder.typicode.com/posts?_limit=5';

async function load() {
    const response = await fetch(URL);

    console.log(
        'Status:',
        response.status,
        'OK:',
        response.ok
    );

    if (!response.ok) {
        throw new Error('Status ' + response.status);
    }

    return response.json();
}

load()
    .then(function (data) {
        console.log('Data API:', data);
    })
    .catch(function (error) {
        console.error('Gagal mengambil data:', error.message);
    });